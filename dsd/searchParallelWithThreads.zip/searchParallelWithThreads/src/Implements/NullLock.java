package Implements;
import Interface.Lock;

public class NullLock implements Lock {
	@Override
	public void releaseCS(int pid) {
	}

	@Override
	public void requestCS(int pid) {
	}
}
