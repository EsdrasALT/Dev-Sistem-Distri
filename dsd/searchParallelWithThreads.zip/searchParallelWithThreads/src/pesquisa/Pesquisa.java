package pesquisa;

import Interface.Lock;

public class Pesquisa extends Thread {
		
    private int myId;
    private Lock lock;
    private int vetor [];
    private int elementoBuscado;
    public Pesquisa(int id, Lock lock, int vetor [], int buscarElemento) {
        myId = id;
        this.lock = lock;
        this.vetor = vetor;
        this.elementoBuscado = buscarElemento;
    }
	
	private void buscarElemento(){
		for (int i = 0; i < vetor.length ; i++) {
			if (vetor[i] == elementoBuscado) {
				System.out.println("Valor " + elementoBuscado + " encontrado no índice " + i);
				return;
			}
		}
		System.out.println("Valor não encontrado");
	}
	
	public void run() {
		buscarElemento();
	}

}
