package main;

import pesquisa.Pesquisa;
import Implements.NullLock;
import Interface.Lock;

public class Main {

	public static void main(String[] args) {
		
		int [] vetor = new int [1000];		
        for (int i = 0; i < vetor.length; i++)
			vetor[i]=i;        
        int buscarElemento = 500;
        int qtdeThread = 5;
        
        Pesquisa t[];
        t = new Pesquisa[qtdeThread];

        Lock lock = new NullLock();
        
        for (int i = 0; i < qtdeThread; i++) {
            t[i] = new Pesquisa(i, lock, vetor, buscarElemento);
            t[i].start();
            
        }
		
	}

}
